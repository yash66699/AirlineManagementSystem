package airlinemanagementsystem;

// Import necessary classes for GUI components
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Class AddCustomer extends JFrame to create a window and implements ActionListener for handling button actions
public class AddCustomer extends JFrame implements ActionListener{
    
    // Declare text fields for user inputs
    JTextField tfname, tfphone, tfaadhar, tfnationality, tfaddress;  
    // Declare radio buttons for gender selection
    JRadioButton rbmale, rbfemale;
    
    // Constructor to initialize the UI components and set up the GUI layout
    public AddCustomer() {
        // Set the background color of the content pane to white
        getContentPane().setBackground(Color.WHITE);
        // Use null layout for absolute positioning of components
        setLayout(null);
        
        // Create a heading label for the Add Customer form
        JLabel heading = new JLabel("ADD CUSTOMER DETAILS");
        heading.setBounds(220, 20, 500, 35);  // Set position and size
        heading.setFont(new Font("Tahoma", Font.PLAIN, 32));  // Set font style
        heading.setForeground(Color.BLUE);  // Set text color
        add(heading);  // Add heading to the frame
        
        // Label for Name input
        JLabel lblname = new JLabel("Name");
        lblname.setBounds(60, 80, 150, 25);  // Set position and size
        lblname.setFont(new Font("Tahoma", Font.PLAIN, 16));  // Set font style
        add(lblname);  // Add the label to the frame
        
        // Text field for entering the customer's name
        tfname = new JTextField();
        tfname.setBounds(220, 80, 150, 25);  // Set position and size
        add(tfname);  // Add the text field to the frame
        
        // Label for Nationality input
        JLabel lblnationality = new JLabel("Nationality");
        lblnationality.setBounds(60, 130, 150, 25);  // Set position and size
        lblnationality.setFont(new Font("Tahoma", Font.PLAIN, 16));  // Set font style
        add(lblnationality);  // Add the label to the frame
        
        // Text field for entering the customer's nationality
        tfnationality = new JTextField();
        tfnationality.setBounds(220, 130, 150, 25);  // Set position and size
        add(tfnationality);  // Add the text field to the frame
        
        // Label for Aadhar Number input
        JLabel lblaadhar = new JLabel("Aadhar Number");
        lblaadhar.setBounds(60, 180, 150, 25);  // Set position and size
        lblaadhar.setFont(new Font("Tahoma", Font.PLAIN, 16));  // Set font style
        add(lblaadhar);  // Add the label to the frame
        
        // Text field for entering the customer's Aadhar number
        tfaadhar = new JTextField();
        tfaadhar.setBounds(220, 180, 150, 25);  // Set position and size
        add(tfaadhar);  // Add the text field to the frame
        
        // Label for Address input
        JLabel lbladdress = new JLabel("Address");
        lbladdress.setBounds(60, 230, 150, 25);  // Set position and size
        lbladdress.setFont(new Font("Tahoma", Font.PLAIN, 16));  // Set font style
        add(lbladdress);  // Add the label to the frame
        
        // Text field for entering the customer's address
        tfaddress = new JTextField();
        tfaddress.setBounds(220, 230, 150, 25);  // Set position and size
        add(tfaddress);  // Add the text field to the frame
        
        // Label for Gender input
        JLabel lblgender = new JLabel("Gender");
        lblgender.setBounds(60, 280, 150, 25);  // Set position and size
        lblgender.setFont(new Font("Tahoma", Font.PLAIN, 16));  // Set font style
        add(lblgender);  // Add the label to the frame
        
        // Group for gender radio buttons to allow only one selection
        ButtonGroup gendergroup = new ButtonGroup();
        
        // Radio button for Male gender
        rbmale = new JRadioButton("Male");
        rbmale.setBounds(220, 280, 70, 25);  // Set position and size
        rbmale.setBackground(Color.WHITE);  // Set background color
        add(rbmale);  // Add the radio button to the frame
        
        // Radio button for Female gender
        rbfemale = new JRadioButton("Female");
        rbfemale.setBounds(300, 280, 70, 25);  // Set position and size
        rbfemale.setBackground(Color.WHITE);  // Set background color
        add(rbfemale);  // Add the radio button to the frame
        
        // Add radio buttons to the button group
        gendergroup.add(rbmale);
        gendergroup.add(rbfemale);
        
        // Label for Phone input
        JLabel lblphone = new JLabel("Phone");
        lblphone.setBounds(60, 330, 150, 25);  // Set position and size
        lblphone.setFont(new Font("Tahoma", Font.PLAIN, 16));  // Set font style
        add(lblphone);  // Add the label to the frame
        
        // Text field for entering the customer's phone number
        tfphone = new JTextField();
        tfphone.setBounds(220, 330, 150, 25);  // Set position and size
        add(tfphone);  // Add the text field to the frame
        
        // Save button to save customer details
        JButton save = new JButton("SAVE");
        save.setBackground(Color.BLACK);  // Set button background color
        save.setForeground(Color.WHITE);  // Set button text color
        save.setBounds(220, 380, 150, 30);  // Set position and size
        save.addActionListener(this);  // Add action listener for button click
        add(save);  // Add the button to the frame
        
        // Load an image icon to display on the frame
        ImageIcon image = new ImageIcon(ClassLoader.getSystemResource("airlinemanagementsystem/icons/emp.png"));
        JLabel lblimage = new JLabel(image);  // Create a label for the image
        lblimage.setBounds(450, 80, 280, 400);  // Set position and size
        add(lblimage);  // Add the image label to the frame
        
        // Set size, position and visibility of the frame
        setSize(900, 600);
        setLocation(300, 150);
        setVisible(true);
    }
    
    // Action performed method when the save button is clicked
    public void actionPerformed(ActionEvent ae) {
        // Retrieve user input from text fields and radio buttons
        String name = tfname.getText();
        String nationality = tfnationality.getText();
        String phone = tfphone.getText();
        String address = tfaddress.getText();
        String aadhar = tfaadhar.getText();
        String gender = null;  // Variable to store selected gender
        
        // Determine the selected gender
        if (rbmale.isSelected()) {
            gender = "Male";  // Set gender to Male if male radio button is selected
        } else {
            gender = "Female";  // Otherwise, set to Female
        }
        
        // Database connection and query execution
        try {
            Conn conn = new Conn();  // Create a new database connection
            
            // SQL query to insert customer details into the passenger table
            String query = "insert into passenger values('"+name+"', '"+nationality+"', '"+phone+"', '"+address+"', '"+aadhar+"', '"+gender+"')";
        
            conn.s.executeUpdate(query);  // Execute the update query
            
            // Show a success message dialog
            JOptionPane.showMessageDialog(null, "Customer Details Added Successfully");
        
            setVisible(false);  // Close the current frame
        } catch (Exception e) {
            e.printStackTrace();  // Print stack trace in case of an exception
        }
    }

    // Main method to run the AddCustomer class
    public static void main(String[] args) {
        new AddCustomer();  // Create an instance of AddCustomer to display the GUI
    }
}
